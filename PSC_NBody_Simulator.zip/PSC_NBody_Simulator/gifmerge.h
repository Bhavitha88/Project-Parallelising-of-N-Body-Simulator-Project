

#include <stdio.h>

#define LONG int
#define ULONG unsigned int
#define BYTE char
#define UBYTE unsigned char
#define SHORT short
#define USHORT unsigned short
#define WORD short int
#define UWORD unsigned short int

#define TRUE 1
#define FALSE 0

typedef struct
{
 int width;
 int height;
 UBYTE m;
 UBYTE cres;
 UBYTE pixbits;
 UBYTE bc;
} GIF_Screen_Hdr; 

typedef union 
{
 struct
 {
  UBYTE red;
  UBYTE green;
  UBYTE blue;
  UBYTE pad;
 } cmap;
 ULONG pixel;
} GIF_Color;

typedef struct
{
 int left;
 int top;
 int width;
 int height;
 UBYTE m;
 UBYTE i;
 UBYTE pixbits;
 UBYTE reserved;
} GIF_Image_Hdr;

typedef struct 
{
 UBYTE valid;
 UBYTE data;
 UBYTE first;
 UBYTE res;
 int last;
} GIF_Table;

