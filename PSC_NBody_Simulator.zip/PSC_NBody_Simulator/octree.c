#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdbool.h>
#include <omp.h>
#include "octree.h"
#include "particle.h"

#define THETA 0.5

#define GRAVITY 4.30091e-3

Octree *create_empty_octree(Space space)
{
    Octree *octree = (Octree *)malloc(sizeof(Octree));
    for (int i = 0; i < 8; i++)
    {
        (octree->children)[i] = NULL;
    }
    octree->value = NULL;
    octree->total_mass = 0.0;
    octree->com_x = 0.0;
    octree->com_y = 0.0;
    octree->com_z = 0.0;
    octree->box_size = space.boundary_x - space.origin_x;
    octree->num_leaves = 0;
    octree->space = space;
    return octree;
}


void print_octree2(Octree *root)
{
    if (root == NULL)
    {
        return;
    }
    if (root->value != NULL)
    {
        printf("%d ", root->value->id);
        printf("(%f, %f, %f) ", root->value->x, root->value->y, root->value->z);
    }

    for (int i = 0; i < 8; i++)
    {
        print_octree2(root->children[i]);
    }
}
Octree *build_octree(int remaining_p, Particle *particles, Space space, int level)
{
    if (remaining_p == 0)
        return NULL;
    if (remaining_p == 1)
    {
        Octree *root = create_empty_octree(space);
        root->value = &particles[0];
        root->total_mass = clamp(particles[0].mass);
        root->com_x = clamp(particles[0].x);
        root->com_y = clamp(particles[0].y);
        root->com_z = clamp(particles[0].z);
        return root;
    }

    Octree *root = create_empty_octree(space);

    // 2D array: particles_in_octant[octant][index]
    Particle **particles_in_octant = (Particle **)malloc(8 * sizeof(Particle *));
    for (int i = 0; i < 8; i++)
    {
        particles_in_octant[i] = (Particle *)malloc(remaining_p * sizeof(Particle));
    }

    int count_in_octant[8] = {0};

    // Distribute particles
    for (int i = 0; i < remaining_p; i++)
    {
        int octant = get_octant(particles[i], space);
        particles_in_octant[octant][count_in_octant[octant]++] = particles[i];
    }

    // Compute subspaces
    Space sub_spaces[8];
    double mid_x = (space.origin_x + space.boundary_x) / 2.0;
    double mid_y = (space.origin_y + space.boundary_y) / 2.0;
    double mid_z = (space.origin_z + space.boundary_z) / 2.0;
    for (int i = 0; i < 8; i++)
    {
        bool gt_mid_x = i & 1;
        bool gt_mid_y = i & 2;
        bool gt_mid_z = i & 4;
        sub_spaces[i].origin_x = gt_mid_x ? mid_x : space.origin_x;
        sub_spaces[i].boundary_x = gt_mid_x ? space.boundary_x : mid_x;
        sub_spaces[i].origin_y = gt_mid_y ? mid_y : space.origin_y;
        sub_spaces[i].boundary_y = gt_mid_y ? space.boundary_y : mid_y;
        sub_spaces[i].origin_z = gt_mid_z ? mid_z : space.origin_z;
        sub_spaces[i].boundary_z = gt_mid_z ? space.boundary_z : mid_z;
    }

    // Aggregate mass & COM
    double total_mass = 0.0;
    double weighted_com_x = 0.0;
    double weighted_com_y = 0.0;
    double weighted_com_z = 0.0;

#pragma omp parallel for reduction(+ : total_mass, weighted_com_x, weighted_com_y, weighted_com_z) if (level == 0)
    for (int i = 0; i < 8; i++)
    {
        int tid = omp_get_thread_num();
        // printf("The thread %d is working on octant %d\n", omp_get_thread_num(), i);
        // printf("The thread %d is working on octant %d\n", omp_get_thread_num(), i);
        Octree *child = build_octree(count_in_octant[i], particles_in_octant[i], sub_spaces[i], 1);
        root->children[i] = child;
        if (child)
        {
            double m = clamp(child->total_mass);
            double cx = clamp(child->com_x);
            double cy = clamp(child->com_y);
            double cz = clamp(child->com_z);
            total_mass = clamp(total_mass + m);
            weighted_com_x = clamp(weighted_com_x + m * cx);
            weighted_com_y = clamp(weighted_com_y + m * cy);
            weighted_com_z = clamp(weighted_com_z + m * cz);
        }
    }

    if (total_mass > 0.0)
    {
        root->total_mass = total_mass;
        root->com_x = clamp(weighted_com_x / total_mass);
        root->com_y = clamp(weighted_com_y / total_mass);
        root->com_z = clamp(weighted_com_z / total_mass);
    }
    else
    {
        root->total_mass = 0.0;
        root->com_x = root->com_y = root->com_z = 0.0;
    }


    return root;
}

void free_octree(Octree *octree)
{
    if (octree == NULL)
    {
        return;
    }
    for (int i = 0; i < 8; i++)
    {
        if ((octree->children)[i] != NULL)
        {
            free_octree((octree->children)[i]);
        }
    }
    free(octree);
}

void update_center_of_mass(Octree *octree, Particle *p)
{
    double total_mass = octree->total_mass + p->mass;
    octree->com_x = clamp(clamp(octree->total_mass * octree->com_x) + clamp(p->x * p->mass)) / total_mass;
    octree->com_y = clamp(clamp(octree->total_mass * octree->com_y) + clamp(p->y * p->mass)) / total_mass;
    octree->com_z = clamp(clamp(octree->total_mass * octree->com_z) + clamp(p->z * p->mass)) / total_mass;
}

void compute_force(Particle *leaf, Octree *octree)
{
    // When we get to a leaf.
    if (octree->value != NULL)
    {
        Particle *l = octree->value;
        double distance = clamp(compute_distance(leaf, l->x, l->y, l->z));

        leaf->force_x += clamp(GRAVITY * leaf->mass * l->mass * clamp((l->x - leaf->x) / clamp(pow(distance, 3.0))));
        leaf->force_y += clamp(GRAVITY * leaf->mass * l->mass * clamp((l->y - leaf->y) / clamp(pow(distance, 3.0))));
        leaf->force_z += clamp(GRAVITY * leaf->mass * l->mass * clamp((l->z - leaf->z) / clamp(pow(distance, 3.0))));
    }
    else
    {
        double distance = clamp(compute_distance(leaf, octree->com_x, octree->com_y, octree->com_z));

        // Use center of mass of octant.
        if ((octree->box_size / distance) < THETA)
        {
            leaf->force_x += clamp(GRAVITY * leaf->mass * octree->total_mass * clamp((octree->com_x - leaf->x) / clamp(pow(distance, 3.0))));
            leaf->force_y += clamp(GRAVITY * leaf->mass * octree->total_mass * clamp((octree->com_y - leaf->y) / clamp(pow(distance, 3.0))));
            leaf->force_z += clamp(GRAVITY * leaf->mass * octree->total_mass * clamp((octree->com_z - leaf->z) / clamp(pow(distance, 3.0))));
        }
        else
        {
        #pragma omp parallel for
            for (int i = 0; i < 8; i++)
            {
                // printf("%d thread is working on octant %d\n", omp_get_thread_num(), i);
                if ((octree->children)[i] != NULL)
                {
                    compute_force(leaf, (octree->children)[i]);
                }
            }
        }
    }
}
